package foodhouse.vn.batch.demo;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@EnableBatchProcessing
@Configuration
public class CsvFileToDatabaseConfig {

//    @Autowired
//    private Environment env;

    @Autowired
    public JobBuilderFactory jobs;

    @Autowired
    public StepBuilderFactory steps;


    @Autowired
    public DataSource dataSource;


    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.sqlite.JDBC");
        dataSource.setUrl("jdbc:sqlite:repository.sqlite");
        dataSource.setUsername("");
        dataSource.setPassword("");
        return dataSource;
    }
    // begin reader, writer, and processor


    @Bean
    public DataSourceInitializer databasePopulator() {
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.addScript(new ClassPathResource("org/springframework/batch/core/schema-sqlf.sql"));
        populator.addScript(new ClassPathResource("sql/reset_user_registration.sql"));
        populator.setContinueOnError(true);
        populator.setIgnoreFailedDrops(true);
        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDatabasePopulator(populator);
        initializer.setDataSource(dataSource());
        return initializer;
    }

//    @Bean
//    @StepScope
//    ItemReader<Map<String, Object>> hdfsFileReader(HdfsResourceLoader resourceLoader, LineMapper<Map<String, Object>> lineMapper) throws IOException {
//        MultiResourceItemReader<Map<String, Object>> multiReader = new MultiResourceItemReader<>();
//        Resource[] resources = resourceLoader.getResources("/demo/influencers/*");
//        multiReader.setResources(resources);
//        FlatFileItemReader<Map<String, Object>> itemReader = new FlatFileItemReader<>();
//        itemReader.setLineMapper(lineMapper);
//        multiReader.setDelegate(itemReader);
//        return multiReader;
//    }

    @Bean
    public FlatFileItemReader<Map<String, String>> csvAnimeReader(){
        FlatFileItemReader<Map<String, String>> reader = new FlatFileItemReader<>();
        reader.setResource(new ClassPathResource("animescsv.csv"));
        reader.setLineMapper(new DefaultLineMapper<Map<String, String>>() {{
            setLineTokenizer(new DelimitedLineTokenizer() {{
                setNames(new String[] { "id", "title", "description" });
            }});
            setFieldSetMapper(new BeanWrapperFieldSetMapper<Map<String, Object>>() {{
                setTargetType(HashMap.class);
            }});
            //read object with fied @annotated as header
        }});
        return reader;
    }

    @Bean
    ItemProcessor<AnimeDTO, AnimeDTO> csvAnimeProcessor() {
        return new AnimeProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<AnimeDTO> csvAnimeWriter() {
        JdbcBatchItemWriter<AnimeDTO> csvAnimeWriter = new JdbcBatchItemWriter<AnimeDTO>();
        csvAnimeWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<AnimeDTO>());
        csvAnimeWriter.setSql("INSERT INTO animes (id, title, description) VALUES (:id, :title, :description)");
        csvAnimeWriter.setDataSource(dataSource);
        return csvAnimeWriter;
    }

    // end reader, writer, and processor

    // begin job info
    @Bean
    public Step csvFileToDatabaseStep() {
        return steps.get("csvFileToDatabaseStep")
                .<AnimeDTO, AnimeDTO>chunk(10)
                .reader(csvAnimeReader())
                .processor(csvAnimeProcessor())
                .writer(csvAnimeWriter())
                .build();
    }

    @Bean(name = "csvFileToDatabaseJob")
    Job csvFileToDatabaseJob(JobCompletionNotificationListener listener) {
        return jobs.get("csvFileToDatabaseJob")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .flow(csvFileToDatabaseStep())
                .end()
                .build();
    }
    // end job info



}
